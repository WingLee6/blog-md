# Trianing

## 版本说明

### Trianing v4.0
+ 


### Trianing v4.0
+ 界面优化
+ 增加机器人管理

### Trianing v3.1
+ 增加部分 jQuery
+ 增加基类Robot
+ 圆周半径类CircleRobot
+ 部分优化


### Trianing v3.0
+ 增加点击域
+ 引入bootstrap
+ 界面改进