# Angularjs Overview

## What is angularjs

[Angularjs(ng for short)](https://angularjs.org/) is a MVC web framework to isolate data and control from view(html). Besides, ng supports multiple views ( or components) which can break down a complicated page or multiple pages into separated html/js files.

## Common directives
- ng-click: bind mouse click event
- ng-model: two way binding. Bind data to html element, such as "input" element. Once user changes value from UI, data will be updated simultaneously. 
- {{}}: one way binding. Binds data to UI. Value can not be modified via UI. eg: "\<label\>{{$ctrl.User.DisplayName}}\</label>"
- ng-change: Bind "changed" event to function.
- ng-class：use expression to define class.
- ng-style: use expression to define style.
- ng-if: use expression to decide whether to have a html element.
- ng-show: use expression to decide whether to show a html element.
- ng-repeat: loops items in a list and generates html element for each item.
- ng-on-xxxx: bind to any DOM xxxx event. For example, ng-on-drop, ng-on-dragOver.

## Best practices
- \#event: A special symbol to pass system parameter to binding function.

```js
<div ng-mousemove="$ctrl.onMouseMove(#event)">
</div>

(function (angular) {
    angular.module('TestApp').component('testCtrl', {
        templateUrl: "./TestApp/components/testCtrl/testCtrl.html",
        bindings: {
            defaultVisibility:'<'
        },
        controller: ['$scope', function ($scope)
        {
            this.onMouseMove = function(e)
            {
            }
        }
     });
```
Without "#event", the "e" parameter passing to this.onMouseMove will be unidentified.

- \#index: In ng-repeat, \#index is the index of current item in list.

- Break down controller code. There might be too many lines of code in a controller. And most of the code has nothing to do with other part of the code in most case. For example, some code in a controller to is load and parse data from files, while some code is to draw something on the UI. The code can be break down as:

testCtrl.js file:
```js
(function (angular) {
    angular.module('TestApp').component('testCtrl', {
        templateUrl: "./TestApp/components/testCtrl/testCtrl.html",
        bindings: {
            defaultVisibility:'<',
            value:'=',
            onEdit:'&'
        },
        controller: ['$scope', function ($scope)
        {
            TestCtrl_Define_Data_Load_Fun(this);
            TestCtrl_Define_Render_Fun(this);
            TestCtrl_Define_UI_Event_Fun(this);
        }
     });
```

testCtrlDataLoad.js file:
```js
function TestCtrl_Define_Data_Load_Fun(host)
{
    host.onUploadFile = function()
    {
    
    }
    
    host.ParseDataFromString = function()
    {
    
    }
}
```
testCtrlRender.js and testCtrlUIEvent.js can be break down in the same way.









