# How does angularjs multiple view works

## Overview
As phone app becomes popular, a new app framework called single page framework is created. In a single page app, there is always one page. When user switch pages, it actually replaces content in the index page instead of opening another page.

Angularjs supports switching content by routing controller/html content by URL path. However, routing is not easy to maintain. Another solution is to use component. A component acts as a html tag. When use that tag in a html page, it will automatically binds to html/controller of that component. There can be more than one components of the same type in a page.

[Angularjs component](https://docs.angularjs.org/guide/component)