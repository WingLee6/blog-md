var Person = function()
{
    this.ID = CreateUUID(); //physoft lib to create GUID.
    this.DisplayName = "person";
}

Person.prototype.Born = function ()
{
    this.DisplayName = "born"; //for test
}

var Student = function()
{
    Person.call(this);

    this.Score = 0;
}

Subclassing(Student, Person); //Subclassing from physoft lib

Student.prototype.Born = function ()
{
    //call super class method first.
    Person.prototype.Born.call(this);

    //then do something related to student
    this.Score = 100;
}
