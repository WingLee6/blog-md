# Multiple View Framework
## Object
- [Understand subclassing](https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/Inheritance)
- How to use subclassing(ref to Subclass-example.js)

## Specification
### Overview

The target of this application is to design sorts of robots which are capable to do sorts of measurement. Each type of robot is limitted to do one kind of measurement. 

#### Robot Type
Currently following types of robot is defined:

`LineRobot`: Given two points P and Q, calculate the distance between P and Q, and also calculate the angle between vector PQ and screen X axis.

`CircleRobot`: Given three points P1, P2, P3, these three points defines a circle C. Calculate the radius of C.

#### User interaction

-`Set Point`: When user click anywhere on the window, it sets position of a point. When click again, it continue to set another point. For LineRobot, when there are two points set, the distance then can be calculated. For CircleRobot, three points are required to be set. When all points are set and user continue to click on the screen, robot falls back to initial state and set the first point.

-`Cancel`:User can press "ESC" key or click cancel button to cancel everything.

-`Switch Robot`: As there are more than one type of robot, user press buttons to switch robot. For example, click "Line" button to use line robot.

#### Robot base class
There are more than one type of robot, all robot follows(inherits from) the same base class.
```
    var Robot = function()
    {
    }

    
       //Do some robot init work if there is.
        //When init a robot and password is required, check and load
        //password from file. This is just a demostration for overload,
        //no need to implement in detail, just left a blank implementaion.
    Robot.prototype.Init = function()
    {
       //do some common init task
    }
```

## Time requirement
Acomplish this training in 1-2 days.