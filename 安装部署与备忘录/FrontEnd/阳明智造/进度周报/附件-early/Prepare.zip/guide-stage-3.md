# Development Design
## Object
- How to use singleton
- [Understand and how to use hashmap](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map)
- How to manage objects

## Specification
### Overview
In this stage, it's not allowed to create robot explicitly. Creation and destroying robot is managed by RobotManager class. "Robot Manager" is special class that can only have one copy of instance

```
     var ROBOT_TYPE_LINE = 0;
     var ROBOT_TYPE_CIRCLE = 1;
      
     var RobotManager = function()
     {

     }

     RobotManager.GetIntance...
     RobotManager.prototype.MakeRobot = function(type)
     {
        return a robot
     }

     RobotManager.prototype.RegisterRobot = function(robot)
     {
     
     }

    //if a robot of "type" not exist, make one.
     RobotManager.prototype.QueryRobotByType = function(type)
    {
 
    }
	
	RobotManager.prototype.QueryRobotType = function()
	{
	  return a list of [{Type: robot type, DisplayName: Robot type name}]. This is a list of all supported robot.
	}
```

Anywhere when you need to visit RobotManager, just call "RobotManager::GetInstance()".


## Time requirement
Acomplish this training in 1-2 days.