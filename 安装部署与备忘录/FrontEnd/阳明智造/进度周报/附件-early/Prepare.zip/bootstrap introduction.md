# Bootstrap Introduction

## Overview
[Bootstrap](https://getbootstrap.com/docs/4.4/getting-started/introduction/) is a popular H5 css/UI framework. Except common components and layout, bootstrap also supports google material design components such as card.

## Layout
The most important layout aspect of bootstrap is the grid system. Use class="row" and class="col-xxxx" to divide page into grid, instead of using style="float:left" nor table to divide page into rows and cols.

And bootstrap provides column class to specifies width of an element instead of definiting width by such as style="width:25%". Bootstrap css is more easy to maintain and keep UI in a consistent way.

## Common components
- Button
- Button groups
- Input groups
- Switch
- Button with icon
- Dropdown(selection)

## Popovers
Popovers is very good way to show tip or help directly around elements. This make user easier to understand and use the software.