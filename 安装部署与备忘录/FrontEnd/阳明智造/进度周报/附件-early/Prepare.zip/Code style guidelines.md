# Code style guidelines

#### Editor

`VS Code`

config `settings.json` file，copy sub settings code to vs code 

```json
{
    "git.enabled": false,
    "search.followSymlinks": false,
    "editor.formatOnSave": false,
    "editor.tabSize": 4,
    "editor.detectIndentation": false,
    "prettier.tabWidth": 4,
    "prettier.printWidth": 130,
    "[javascript]": {
        "editor.defaultFormatter": "esbenp.prettier-vscode"
    },
    "[html]": {
        "editor.defaultFormatter": "esbenp.prettier-vscode"
    },
    "[json]": {
        "editor.defaultFormatter": "esbenp.prettier-vscode"
    },
    "[css]": {
        "editor.defaultFormatter": "esbenp.prettier-vscode"
    },

    "[typescript]": {
        "editor.defaultFormatter": "esbenp.prettier-vscode"
    },

    "[jsonc]": {
        "editor.defaultFormatter": "esbenp.prettier-vscode"
    },
}
```



#### Plugins

`Path Intellisense` : Visual Studio Code plugin that autocompletes filenames.

`Prettier - Code formatter` ：[Prettier](https://prettier.io/) is an opinionated code formatter. 

`Rainbow Brackets` : Provide rainbow colors for the round brackets, the square brackets and the squiggly brackets. 



#### Code Specifications

1. 定义变量放在方法最前面，类似C++，先定义变量再使用，而且要注意初始化，
2. 变量定义遵守变量命名规范，不同类型添加前缀
3. 全局方法提前在构造函数定义
4. 方法添加简要说明





