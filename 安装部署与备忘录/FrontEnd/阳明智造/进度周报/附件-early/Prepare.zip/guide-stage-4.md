# Development Design
## Object
- What is physoft multiple view framework (MVF)(read [Physoft app framework structure.md](./Physoft app framework structure.md))
- What is Angularjs(ng) and how does it works.(read [Angularjs overview.md](./Angularjs overview.md))
- How does ng multiple view works.(read [How does angularjs multiple view works.md](./How does angularjs multiple view works.md))
- Be familiar with Physoft naming conventions.
- Be familiar with Physoft coding style.

## Specification
### Overview
In this stage,you need know how does it work MVF(physoft multiple view framework) and use angularjs  in MVF.

RobotManager class and bootstrap ui has complete by js,now you should import it to MVF.


## Time requirement
Acomplish this training in 2-5 days.