# Multiple View Framework
## Object
- Be familiar with Physoft naming conventions.
- Be familiar with Physoft coding style.
- Be familiar with common ng directive.
- Be familiar with bootstrap grid system and common component.

## Specification
### Overview

The target of this app is to measure distance and angle between two point P and Q. Assume there is a coordinate on the window, where X axis is horizontally from left to right and y axis is vertically from bottom to top.
```
                  /\         y axis
                  |
                  |
          ---------------->   X axis
                  | 
                  |

                           P
                          /
                         /  (a)
                        /_________  x axis
                       Q
```



When user click anywhere on the window, it sets the position of P. When click again, it sets the position of Q and the application then calculate the distance between PQ. And calculate the angle 'a' between vector PQ and x axis as well. The angle is started from x axis and rotate anti-clockwise.

User can press "ESC" key or click cancel button to cancel everything.

### UI layout

```
-------------------------------------------------
|        |            2                           |
|    1   |--------------------------------------- |
|        |                                        |
|        |                     3                  |
|        |                                        |
|-------------------------------------------------|
|                        4                        |
|-------------------------------------------------|
```

1: Button area: Button to cancel measurement, button to switch measurement function such as line, circle.

2: Title area: Show current state, measurement result etc. Text color is red when result is not avaiable, color is green otherwise.

3: Measurement area: No need to draw anything in current version.

4: Reserved area: not used for now.

## Design requirement
1.Use bootstrap

2.Create class "LineRobot", file name is LineRobot.js

3.Add following public methods to LineRobot.

```
//Set P or Q, depends on current state.
//return int
SetPoint(float x, float y);

//It's available only when Start point and end point is both set.
//return bool
//return true if it's available to calculate distance and angle.
IsAvailable(); 

//return >=0 if cancel succeeded.
//return <0 otherwise.
Cancel();

//Get current state, for example, return "P1", "P2" to indicate user is in state of setting point P1, P2 respectively. Return result when all points is ready, for example "d = 10px, a = 5°"
//return string. 
GetState(); 
```

## Time requirement
Accomplish this training in 2~4 days.