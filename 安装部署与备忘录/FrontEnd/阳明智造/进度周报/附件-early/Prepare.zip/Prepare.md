

#		Employee induction training

### 2.Learning Steps

`Tip ` If you have a front-end related foundation, you can skip the learning and go directly to the training task.

#### 2.1.H5

Learn the basic skills required for front-end h5 development,and then implement the functions in the training task.

The following websites can be used as a reference to learn related knowledge.

* [JavaScript](https://www.runoob.com/js/js-tutorial.html)

* [CSS](https://www.runoob.com/css/css-tutorial.html)

* [HTML](https://www.runoob.com/html/html-tutorial.html)

#####  Training 2.1:

Use javascript to achieve the following functions, get the coordinates of two points on the screen, and then calculate the angle between the two points.

`Time`

Study time: `1~3` weeks

Accomplish this training in `2` days.



#### 2.2.Bootstrap

bootstrap is a ui lib based on jquery. Before using it, you need to learn the simplest basic usage of jquery and related usage of UI library

* [bootstrap 4.3.1](https://getbootstrap.com/docs/4.3/getting-started/introduction/)

* [jquery 2.1.4](https://www.runoob.com/jquery/jquery-tutorial.html)

##### Training:

Read [guide-stage-1.md](./guide-stage-1.md) ,[guide-stage-2.md](./guide-stage-2.md) ,[guide-stage-3.md](./guide-stage-3.md) and accomplish this training in this order

  ##### Time

Study time: `1~2` weeks

Accomplish this training in `4~8` days.



####  2.3.Angular

Learn the front-end framework angularjs,you sholud know what is Angularjs(ng) and how does it works, and read [Angularjs overview.md](./Angularjs overview.md).

The following websites can be used as a reference to learn related knowledge.

* [angularjs runoob](https://www.runoob.com/angularjs/angularjs-tutorial.html)
* [angularjs 1.5.6](https://code.angularjs.org/1.5.6/docs/tutorial)
* [angularjs cn](https://www.angularjs.net.cn/tutorial/)

#####  Training:

Read [guide-stage-4.md](./guide-stage-4.md) and accomplish this training

##### Time

Study time: 1~2 weeks

Accomplish this training in 5 days.



#### 2.4.Physoft API

Physoft encapsulates a series of APIs to implement measurement and common functions.Such as:

* LocalFileSystem
* EventHandler
* Lang
* GeoMath
* Vector3
* Thread
* Trace
* Run Command
* ...

#####  Training:

Learning use several common `Physoft API` in MVF.

##### Time

Study time: 1~2 weeks

Accomplish this training in 5 days.



#### 2.5.Physoft Measure

* Use FI/FD/AppSimulator

* Action/ResultHandler

* Device Pool

* Workflow.Runtime/Workflow.Render

* three.js/d3.js

* PhySDK

* Powershell/cmd

  







